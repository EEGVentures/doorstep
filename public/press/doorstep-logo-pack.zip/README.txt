Doorstep logo pack

Use the lockup (emblem + wordmark) on light backgrounds and the reverse lockup on dark ones.
Use the emblem on its own only where the Doorstep name appears nearby.
Please don't recolour, stretch, outline, add effects to or retype the logo.
Leave clear space around it of at least one head of the outer figures in the emblem.

Press enquiries: press@doorstep.live
